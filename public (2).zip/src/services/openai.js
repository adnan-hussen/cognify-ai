// services/openai.js
export async function generateLesson(content) {
    const endpoint = "YOUR_AZURE_OPENAI_ENDPOINT";
    const key = "YOUR_AZURE_OPENAI_KEY";
    const deploymentId = "gpt-4o";

    const response = await fetch(
        `${endpoint}/openai/deployments/${deploymentId}/chat/completions?api-version=2024-02-15-preview`,
        {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'api-key': key
            },
            body: JSON.stringify({
                messages: [
                    {
                        role: "system",
                        content: `You are an expert educator specializing in creating interactive lessons for students with ADHD.
                        Convert educational content into an engaging lesson following this JSON structure:
                        {
                          "title": "Topic title",
                          "estimatedDuration": "X minutes",
                          "steps": [
                            {
                              "type": "explanation",
                              "title": "Concept title",
                              "content": "Clear explanation",
                              "emphasis": ["key term 1", "key term 2"]
                            },
                            {
                              "type": "example",
                              "title": "Real World Example",
                              "content": "Practical example",
                              "imageDescription": "Visual aid description"
                            },
                            {
                              "type": "quiz",
                              "question": "Test question",
                              "options": ["Correct", "Wrong 1", "Wrong 2", "Wrong 3"],
                              "correctAnswer": 0,
                              "explanation": "Why this is correct"
                            }
                          ]
                        }`
                    },
                    {
                        role: "user",
                        content: content
                    }
                ],
                temperature: 0.7,
                max_tokens: 2000
            })
        }
    );

    const data = await response.json();
    return JSON.parse(data.choices[0].message.content);
}