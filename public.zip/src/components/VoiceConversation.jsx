"use client";

import React, { useState, useRef, useEffect } from "react";
import { Button, Form, InputGroup, Accordion } from "react-bootstrap";
import { Power, Mic, MicOff, Send } from "lucide-react";
import { RTClient } from "rt-client";
import { AudioHandler } from "@/lib/audio";

const VoiceConversation = () => {
  const [isAzure, setIsAzure] = useState(false);
  const [apiKey, setApiKey] = useState("");
  const [endpoint, setEndpoint] = useState("");
  const [deployment, setDeployment] = useState("");
  const [useVAD, setUseVAD] = useState(true);
  const [instructions, setInstructions] = useState("");
  const [temperature, setTemperature] = useState(0.9);
  const [modality, setModality] = useState("audio");
  const [tools, setTools] = useState([]);
  const [messages, setMessages] = useState([]);
  const [currentMessage, setCurrentMessage] = useState("");
  const [isRecording, setIsRecording] = useState(false);
  const [isConnected, setIsConnected] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  const clientRef = useRef(null);
  const audioHandlerRef = useRef(null);

  const addTool = () => setTools([...tools, { name: "", parameters: "", returnValue: "" }]);

  const updateTool = (index, field, value) => {
    const newTools = [...tools];
    newTools[index][field] = value;
    setTools(newTools);
  };

  const handleConnect = async () => {
    if (!isConnected) {
      try {
        setIsConnecting(true);
        clientRef.current = isAzure
          ? new RTClient(new URL(endpoint), { key: apiKey }, { deployment })
          : new RTClient({ key: apiKey }, { model: "gpt-4o-realtime-preview-2024-10-01" });

        const modalities = modality === "audio" ? ["text", "audio"] : ["text"];
        const turnDetection = useVAD ? { type: "server_vad" } : null;

        clientRef.current.configure({
          instructions: instructions || undefined,
          input_audio_transcription: { model: "whisper-1" },
          turn_detection: turnDetection,
          tools,
          temperature,
          modalities,
        });

        startResponseListener();
        setIsConnected(true);
      } catch (error) {
        console.error("Connection failed:", error);
      } finally {
        setIsConnecting(false);
      }
    } else {
      await disconnect();
    }
  };

  const disconnect = async () => {
    if (clientRef.current) {
      try {
        await clientRef.current.close();
        clientRef.current = null;
        setIsConnected(false);
      } catch (error) {
        console.error("Disconnect failed:", error);
      }
    }
  };

  const startResponseListener = async () => {
    if (!clientRef.current) return;

    try {
      for await (const serverEvent of clientRef.current.events()) {
        if (serverEvent.type === "response") {
          await handleResponse(serverEvent);
        } else if (serverEvent.type === "input_audio") {
          await handleInputAudio(serverEvent);
        }
      }
    } catch (error) {
      console.error("Response iteration error:", error);
    }
  };

  const handleResponse = async (response) => {
    for await (const item of response) {
      if (item.type === "message" && item.role === "assistant") {
        const message = { type: item.role, content: "" };
        setMessages((prevMessages) => [...prevMessages, message]);

        for await (const content of item) {
          if (content.type === "text") {
            for await (const text of content.textChunks()) {
              message.content += text;
              setMessages((prevMessages) => {
                const updatedMessages = [...prevMessages];
                updatedMessages[updatedMessages.length - 1].content = message.content;
                return updatedMessages;
              });
            }
          }
        }
      }
    }
  };

  const handleInputAudio = async (item) => {
    audioHandlerRef.current?.stopStreamingPlayback();
    await item.waitForCompletion();
    setMessages((prevMessages) => [
      ...prevMessages,
      { type: "user", content: item.transcription || "" },
    ]);
  };

  const sendMessage = async () => {
    if (currentMessage.trim() && clientRef.current) {
      try {
        setMessages((prevMessages) => [...prevMessages, { type: "user", content: currentMessage }]);

        await clientRef.current.sendItem({
          type: "message",
          role: "user",
          content: [{ type: "input_text", text: currentMessage }],
        });

        await clientRef.current.generateResponse();
        setCurrentMessage("");
      } catch (error) {
        console.error("Failed to send message:", error);
      }
    }
  };

  const toggleRecording = async () => {
    if (!isRecording) {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        console.log("Microphone permission granted:", stream);

        audioHandlerRef.current = new AudioHandler();
        await audioHandlerRef.current.initialize();

        await audioHandlerRef.current.startRecording((chunk) => {
          console.log("Audio chunk received:", chunk);
          if (clientRef.current) clientRef.current.sendAudio(chunk);
        });

        setIsRecording(true);
      } catch (error) {
        console.error("Error accessing microphone or starting recording:", error);
      }
    } else {
      if (audioHandlerRef.current) {
        audioHandlerRef.current.stopRecording();
        setIsRecording(false);
      }
    }
  };

  useEffect(() => {
    return () => {
      disconnect();
      if (audioHandlerRef.current) audioHandlerRef.current.close();
    };
  }, []);

  return (
    <div className="d-flex flex-column vh-100">
      <div className="p-3 bg-light border-bottom">
        <Accordion>
          <Accordion.Item eventKey="0">
            <Accordion.Header>Connection Settings</Accordion.Header>
            <Accordion.Body>
              <Form.Check
                type="switch"
                label="Use Azure OpenAI"
                checked={isAzure}
                onChange={() => setIsAzure(!isAzure)}
                disabled={isConnected}
              />
              {isAzure && (
                <>
                  <Form.Control
                    type="text"
                    placeholder="Azure Endpoint"
                    value={endpoint}
                    onChange={(e) => setEndpoint(e.target.value)}
                    disabled={isConnected}
                    className="my-2"
                  />
                  <Form.Control
                    type="text"
                    placeholder="Deployment Name"
                    value={deployment}
                    onChange={(e) => setDeployment(e.target.value)}
                    disabled={isConnected}
                    className="my-2"
                  />
                </>
              )}
              <Form.Control
                type="password"
                placeholder="API Key"
                value={apiKey}
                onChange={(e) => setApiKey(e.target.value)}
                disabled={isConnected}
                className="my-2"
              />
            </Accordion.Body>
          </Accordion.Item>
        </Accordion>
        <Button
          className="mt-3"
          onClick={handleConnect}
          disabled={isConnecting}
          variant={isConnected ? "danger" : "primary"}
        >
          <Power className="me-2" />
          {isConnecting ? "Connecting..." : isConnected ? "Disconnect" : "Connect"}
        </Button>
      </div>

      <div className="flex-grow-1 p-3 overflow-auto">
        {messages.map((message, index) => (
          <div
            key={index}
            className={`p-3 rounded mb-2 ${
              message.type === "user" ? "bg-primary text-white ms-auto" : "bg-secondary text-white me-auto"
            }`}
            style={{ maxWidth: "75%" }}
          >
            {message.content}
          </div>
        ))}
      </div>

      <div className="p-3 border-top">
        <InputGroup>
          <Form.Control
            placeholder="Type your message..."
            value={currentMessage}
            onChange={(e) => setCurrentMessage(e.target.value)}
            onKeyUp={(e) => e.key === "Enter" && sendMessage()}
            disabled={!isConnected}
          />
          <Button
            variant={isRecording ? "danger" : "outline-secondary"}
            onClick={toggleRecording}
            disabled={!isConnected}
          >
            {isRecording ? <MicOff /> : <Mic />}
          </Button>
          <Button variant="primary" onClick={sendMessage} disabled={!isConnected}>
            <Send />
          </Button>
        </InputGroup>
      </div>
    </div>
  );
};

export default VoiceConversation;
