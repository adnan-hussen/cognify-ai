// services/documentIntelligence.js
export async function extractTextFromDocument(file) {
    const endpoint = "YOUR_DOCUMENT_INTELLIGENCE_ENDPOINT";
    const key = "YOUR_DOCUMENT_INTELLIGENCE_KEY";

    const formData = new FormData();
    formData.append('file', file);

    const response = await fetch(`${endpoint}/formrecognizer/documentModels/prebuilt-document:analyze?api-version=2023-10-31`, {
        method: 'POST',
        headers: {
            'Ocp-Apim-Subscription-Key': key
        },
        body: formData
    });

    if (!response.ok) {
        throw new Error('Failed to analyze document');
    }

    // Get operation-location header for polling
    const operationLocation = response.headers.get('operation-location');

    // Poll until completion
    while (true) {
        const pollResponse = await fetch(operationLocation, {
            headers: {
                'Ocp-Apim-Subscription-Key': key
            }
        });
        
        const result = await pollResponse.json();
        
        if (result.status === 'succeeded') {
            return result.analyzeResult.content;
        } else if (result.status === 'failed') {
            throw new Error('Document analysis failed');
        }

        // Wait before next poll
        await new Promise(resolve => setTimeout(resolve, 1000));
    }
}